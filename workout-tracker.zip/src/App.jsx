import WorkoutTracker from './WorkoutTracker';

function App() {
  return (
    <div className="min-h-screen bg-gray-100">
      <WorkoutTracker />
    </div>
  );
}

export default App;